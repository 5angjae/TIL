
public class SpeakTest {
public static void main(String[] args) {
	Object[] obj = {new Reader("�浿"),
			new Worker("�Ѹ�"),
			new Student("������")};
	for (int i = 0; i < obj.length; i++) {
		if(obj[i] instanceof Speakable){
			Speakable speaker = (Speakable)obj[i];
			System.out.println(speaker.speak());
		}
	}
}
}
