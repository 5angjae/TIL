package speak;

public interface Speakable {
	public String speak();
}
